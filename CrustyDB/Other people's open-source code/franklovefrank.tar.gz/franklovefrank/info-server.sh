RUST_LOG=info cargo run --bin server
