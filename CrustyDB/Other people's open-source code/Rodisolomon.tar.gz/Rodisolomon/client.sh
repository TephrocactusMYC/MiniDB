cargo run --bin cli-crusty
