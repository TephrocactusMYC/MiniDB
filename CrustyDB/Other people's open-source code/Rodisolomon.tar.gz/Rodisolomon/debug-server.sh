RUST_LOG=debug cargo run --bin server
